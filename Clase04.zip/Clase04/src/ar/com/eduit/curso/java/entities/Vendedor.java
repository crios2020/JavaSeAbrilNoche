package ar.com.eduit.curso.java.entities;

public class Vendedor extends Persona{
    private int nroLegajo;
    private double sueldoBasico;

    public Vendedor(int nroLegajo, double sueldoBasico, String nombre, int edad, Direccion direccion) {
        super(nombre, edad, direccion);     //llama al constructor de la clase padre
        this.nroLegajo = nroLegajo;
        this.sueldoBasico = sueldoBasico;
    }

    @Override
    public void saludar() {
        System.out.println("Hola soy un vendedor!");
    }

    @Override
    public String toString() {
        return "Vendedor{" + "nroLegajo=" + nroLegajo + ", sueldoBasico=" + sueldoBasico +'}'+super.toString();
    }

    public int getNroLegajo() {
        return nroLegajo;
    }

    public double getSueldoBasico() {
        return sueldoBasico;
    }
 
}