package ar.com.eduit.curso.java.interfaces;

public interface I_File {

    /*
    Interfaces:
    - No tienen constructores ni atributos.
    - No tiene miembros privados, todos los miembros son publicos.
    - Solo puede tener atributos constances(final), o atributos static.
    - Todos los métodos son publicos, y tambien son abstractos.
    - Una clase puede implementar muchas interfaces.
    */
    
    /**
     * Método para escribir un archivo.
     * @param text Texto a imprimir.
     */
    void setText(String text);
    
    /**
     * Método para leer un archivo.
     * @return 
     */
    String getText();
    
    //métodos default en java 8
    default void info(){
        System.out.println("Interface I_File");
    }
    
}