package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.entities.Cliente;
import ar.com.eduit.curso.java.entities.Cuenta;
import ar.com.eduit.curso.java.entities.Direccion;
import ar.com.eduit.curso.java.entities.Persona;
import ar.com.eduit.curso.java.entities.Vendedor;

public class TestHerencia {
    public static void main(String[] args) {
        //test Diagrama Herencia
        
        System.out.println("-- dir1 --");
        Direccion dir1=new Direccion("Lima", 180, "1", "a");
        System.out.println(dir1);

        System.out.println("-- dir2 --");
        Direccion dir2=new Direccion("Belgrano", 48, null, null, "Moron");
        System.out.println(dir2);
        
        /*
        System.out.println("-- persona1 --");
        Persona persona1=new Persona("Jesus", 50, dir2);
        System.out.println(persona1);
        persona1.saludar();
        
        System.out.println("-- persona2 --");
        Persona persona2=new Persona("Esteban",40, dir2);
        System.out.println(persona2);
        persona2.saludar();
        */
        
        System.out.println("-- vendedor1 --");
        Vendedor vendedor1 = new Vendedor(1, 90000, "Jose Pereyra", 56, dir2);
        System.out.println(vendedor1);
        vendedor1.saludar();
        
        System.out.println("-- cliente1 --");
        Cliente cliente1=new Cliente(1, new Cuenta(10,"arg$"), "Liliana Correa", 30, dir1);
        System.out.println(cliente1);
        cliente1.saludar();
        
        // Poliformismo - Polimorfismo
        Persona p1=new Vendedor(1, 700000, "Javier Molina", 26, dir2);
        Persona p2=new Cliente(2, new Cuenta(11,"arg$"), "Miguel Lezcano", 30, dir2);
        
        p1.saludar();
        p2.saludar();
        
        Vendedor v1=(p1 instanceof Vendedor)?(Vendedor)p1:null;
        
        System.out.println(v1.getClass());
        System.out.println(v1.getClass().getName());
        System.out.println(v1.getClass().getSimpleName());
        System.out.println(v1.getClass().getSuperclass().getName());
        System.out.println(v1.getClass().getSuperclass().getSuperclass().getName());
        System.out.println(v1.getClass().getSuperclass().getSuperclass().getSuperclass());
        System.out.println("Hola".getClass().getName());
        System.out.println("Hola".getClass().getSuperclass().getName());
        
    }
}