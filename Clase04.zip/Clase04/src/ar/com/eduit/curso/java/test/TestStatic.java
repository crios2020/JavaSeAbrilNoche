package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.entities.Auto;

public class TestStatic {
    public static void main(String[] args) {
        System.out.println("Hoy es Jueves!");
        Auto.acelerar();
        
        Auto auto1=new Auto("Honda", "Civic", "Blanco");
        auto1.acelerar();
        System.out.println(auto1+" "+auto1.getVelocidad());
        
        Auto auto2=new Auto("Toyota","Corolla","Negro");
        auto2.acelerar();
        System.out.println(auto2+" "+auto2.getVelocidad());
        
        System.out.println("Velocidad "+Auto.getVelocidad());
    }
}