package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.entities.ClienteEmpresa;
import ar.com.eduit.curso.java.entities.ClientePersona;
import ar.com.eduit.curso.java.entities.Cuenta;
import java.util.ArrayList;


public class TestRelaciones {
    public static void main(String[] args) {
        
        //Objetos MOCKS
        
        System.out.println("-- cuenta1 --");
        Cuenta cuenta1=new Cuenta(1, "args");
        cuenta1.depositar(80000);
        cuenta1.depositar(90000);
        cuenta1.debitar(25000);
        System.out.println(cuenta1);
        
        System.out.println("-- clientePersona1 --");
        ClientePersona clientePersona1=new ClientePersona(1, "Raul Peres", 40, cuenta1);
        clientePersona1.getCuenta().depositar(20000);
        System.out.println(clientePersona1);
        
        
        System.out.println("-- Matrimonio: clienteAna - clienteJose");
        ClientePersona clienteAna=new ClientePersona(2,"Ana",35,new Cuenta(2,"Args"));
        clienteAna.getCuenta().depositar(50000);
        
        ClientePersona clienteJose=new ClientePersona(3,"Jose",35,clienteAna.getCuenta());
        clienteJose.getCuenta().debitar(20000);
        
        System.out.println(clienteAna);
        System.out.println(clienteJose);
        
        System.out.println("-- clientePersona4 --");
        ClientePersona clientePersona4=new ClientePersona(4, "Mirta", 50, 3, "Args");
        clientePersona4.getCuenta().depositar(80000);
        clientePersona4.getCuenta().debitar(10000);
        System.out.println(clientePersona4);
        
        
        System.out.println("-- clienteEmpresa1 --");
        ClienteEmpresa clienteEmpresa1=new ClienteEmpresa(1, "Todo limpio srl", "Lima 222");
        ArrayList<Cuenta> cuentas=clienteEmpresa1.getCuentas();
        cuentas.add(new Cuenta(10,"arg$"));         // 0
        cuentas.add(new Cuenta(11,"reales"));       // 1
        cuentas.add(new Cuenta(11,"U$S"));          // 2
        cuentas.get(0).depositar(240000);
        cuentas.get(0).depositar(120000);
        cuentas.get(1).depositar(80000);
        cuentas.get(2).depositar(12000);
        
        System.out.println(clienteEmpresa1);
        for(int a=0;a<cuentas.size();a++) System.out.println(cuentas.get(a));
        String texto="Hola";
        
        
        
    }
}