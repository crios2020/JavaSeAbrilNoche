package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.entities.Direccion;
import ar.com.eduit.curso.java.entities.Persona;

public class TestHerencia {
    public static void main(String[] args) {
        //test Diagrama Herencia
        
        System.out.println("-- dir1 --");
        Direccion dir1=new Direccion("Lima", 180, "1", "a");
        System.out.println(dir1);

        System.out.println("-- dir2 --");
        Direccion dir2=new Direccion("Belgrano", 48, null, null, "Moron");
        System.out.println(dir2);
        
        /*
        System.out.println("-- persona1 --");
        Persona persona1=new Persona("Jesus", 50, dir2);
        System.out.println(persona1);
        persona1.saludar();
        
        System.out.println("-- persona2 --");
        Persona persona2=new Persona("Esteban",40, dir2);
        System.out.println(persona2);
        persona2.saludar();
        */
        
        
    }
}