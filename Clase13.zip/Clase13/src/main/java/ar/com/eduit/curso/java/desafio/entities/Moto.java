package ar.com.eduit.curso.java.desafio.entities;

public class Moto extends Vehiculo {
    private int cilindrada;

    public Moto(String marca, String modelo, double precio, int cilindrada) {
        super(marca, modelo, precio);
        this.cilindrada = cilindrada;
    }

    @Override
    public String toString() {
        return super.toString()+"Cilindrada: "+cilindrada+"c"+getPrecioFormat();
    }

    public int getCilindrada() {
        return cilindrada;
    }

}
