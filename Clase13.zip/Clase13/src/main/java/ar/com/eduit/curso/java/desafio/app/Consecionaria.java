package ar.com.eduit.curso.java.desafio.app;

import ar.com.eduit.curso.java.desafio.entities.Auto;
import ar.com.eduit.curso.java.desafio.entities.Moto;
import ar.com.eduit.curso.java.desafio.entities.Vehiculo;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Consecionaria {
    
    private static List<Vehiculo> vehiculos=new ArrayList();
    
    public static void main(String[] args) {
        
        cargar();
        
        listar();
        
        separador();
  
        vehiculoMasCaro();
                
        vehiculoMasBarato();
        
        vehiculoY();
        
        separador();
        
        ordenPorPrecio();
        
        separador();
        
        ordenNatural();
        
    }

    private static void ordenNatural() {
        vehiculos
                .stream()
                .sorted()
                .forEach(System.out::println);
    }
    
    private static void ordenPorPrecio() {
        vehiculos
                .stream()
                .sorted(Comparator.comparingDouble(Vehiculo::getPrecio).reversed())
                .forEach(v->System.out.println(v.getMarca()+" "+v.getModelo()));
    }

    private static void vehiculoY() {
        Vehiculo vehiculoY=vehiculos
                .stream()
                .filter(v->v.getModelo().contains("Y"))
                .findFirst()
                .get();
        System.out.println("Vehiculo que contiene en el modelo la letra 'Y': "
                +vehiculoY.getMarca()+" "+vehiculoY.getModelo()+" $"
                +new DecimalFormat("###,###,###.00").format(vehiculoY.getPrecio()));
    }

    private static void vehiculoMasCaro() {
        Vehiculo vehiculoMasCaro = vehiculos
                .stream()
                .max(Comparator.comparingDouble(Vehiculo::getPrecio))
                .get();
        System.out.println("Vehiculo más caro: "
                +vehiculoMasCaro.getMarca()+" "
                +vehiculoMasCaro.getModelo());
    }

    private static void vehiculoMasBarato() {
        Vehiculo vehiculoMasBarato = vehiculos
                .stream()
                .min(Comparator.comparingDouble(Vehiculo::getPrecio))
                .get();
        System.out.println("Vehiculo más barato: "
                +vehiculoMasBarato.getMarca()+" "
                +vehiculoMasBarato.getModelo());
    }
    private static void separador() {
        System.out.println("");
        System.out.println("=================================================");
        System.out.println("");
    }

    private static void listar() {
        vehiculos.forEach(System.out::println);
    }
    
    private static void cargar(){
        vehiculos.add(new Auto("Peugeot","206",200000,4));
        vehiculos.add(new Moto("Honda","Titan",60000,125));
        vehiculos.add(new Auto("Peugeot","208",250000,5));
        vehiculos.add(new Moto("Yamaha","YBR",80500.5,160));
    }
}
