package clase06;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.Vector;

public class Clase06 {

    public static void main(String[] args) {
        
        //Arrays - Vectores
        Auto[] autos=new Auto[4];
        autos[0]=new Auto("Fiat","Idea","Gris");
        autos[1]=new Auto("Ford","Ka","Negro");
        autos[2]=new Auto("VW","Gol","Rojo");
        autos[3]=new Auto("Citroen","C4","Bordo");
        
        //Recorrido con indices
        //for(int a=0;a<autos.length;a++) System.out.println(autos[a]);
        
        //Recorrido forEach
        for(Auto a:autos) System.out.println(a);
        
        //Interface List
        List lista;
        
        lista=new ArrayList();
        //lista=new LinkedList();
        //lista=new Vector();
        
        lista.add(new Auto("Renault","Kangoo","Verde"));            //0
        lista.add(new Auto("Chevrolet","Corsa","Azul"));            //1
        lista.add("Hola");                                          //2
        lista.add(22);                                              //3
        
        //Copiar los autos del array autos a lista
        for(Auto a:autos) lista.add(a);
        
        
        System.out.println("****************************************************");
        //Recorrido con indices
        //for(int a=0;a<lista.size();a++) System.out.println(lista.get(a));
        
        //Recorrido forEach
        //for(Object o:lista) System.out.println(o);
        
        //Recorrido con metodo default forEach() JDK 8 0 sup.
        //lista.forEach(o->System.out.println(o));
        //lista.forEach(o->{
        //    System.out.println(o);
        //    System.out.println("-");
        //});
        lista.forEach(System.out::println);
        
        //Uso de Generics <E>
        List<Auto> lista2=new ArrayList();
        lista2.add(new Auto("Peugeot","3008","Gris"));
        lista2.add(new Auto("Honda","City","Blanco"));
        
        Auto auto1=(Auto)lista.get(0);
        Auto auto2=lista2.get(0);
       
        //Copiar los autos de lista a lista2
        lista.forEach(o->{
            if(o instanceof Auto) lista2.add((Auto)o);
        });
        
        lista2.add(0, new Auto("Toyota","Corolla","Blanco"));
        lista2.remove(1);
        lista2.add(1,auto2);
        
        
        System.out.println("****************************************************");
        lista2.forEach(System.out::println);
        
        
        //Interface Set
        Set<String> set;

        //Implementación HashSet: Almacena elementos de la fomar más veloz posible.
        //                          No garantiza el orden de los elementos.
        //set=new HashSet();
        
        //Implementación LinkedHashSet: Almacena elementos en una lista enlazada, por orden de ingreso
        //set=new LinkedHashSet();
        
        //Implementación TreeSet: Almacena elementos en una arbol. lista los elementos en forma ordenada
        set=new TreeSet();
        
        //app
        set.add("Lunes");
        set.add("Martes");
        set.add("Miércoles");
        set.add("Jueves");
        set.add("Viernes");
        set.add("Lunes");
        set.add("Martes");
        set.add("Sábado");
        set.add("Domingo");
        set.forEach(System.out::println);
        
        Set<Auto>setAutos;
        //setAutos=new LinkedHashSet();
        setAutos=new TreeSet();
        
        setAutos.addAll(lista2);
        setAutos.add(new Auto("Citroen","C4","Bordo"));
        setAutos.add(new Auto("Citroen","C3","Bordo"));
        setAutos.add(new Auto("Citroen","C3","Azul"));
        setAutos.add(new Auto("Citroen","C6","Verde"));
        setAutos.add(new Auto("Citroen","C5","Verde"));
        
        System.out.println("****************************************************");
        setAutos.forEach(auto->System.out.println(auto+"\t"+auto.hashCode()));
        
        System.out.println("****************************************************");
        lista2.stream().sorted(Comparator.comparing(Auto::getColor)).forEach(System.out::println);
        
        /*
            Pilas stack         LIFO Last In First Out
        
        
            Colas queue         FIFO First In First Out
        
        */
        
        
        Stack<Auto>pilaAutos=new Stack();
        pilaAutos.push(new Auto("Renault","Clio","Blanco"));
        // .push()  apila un elemento en la lista.
        
        pilaAutos.addAll(lista2);
        
        System.out.println("****************************************************");
        pilaAutos.forEach(System.out::println);
        System.out.println("****************************************************");
        System.out.println("Longitud de pila: "+pilaAutos.size());
        while(!pilaAutos.isEmpty()){
            System.out.println(pilaAutos.pop());
            // .pop() desapila un elemento de la lista.
        }
        System.out.println("Longitud de pila: "+pilaAutos.size());
        
        System.out.println("****************************************************");
        ArrayDeque<Auto>colaAutos=new ArrayDeque();
        colaAutos.offer(new Auto("VW","Polo","Verde"));
        // .offer() encola un elemento en la lista
        colaAutos.addAll(lista2);
        System.out.println("****************************************************");
        colaAutos.forEach(System.out::println);
        System.out.println("****************************************************");
        System.out.println("Longitud de cola: "+colaAutos.size());
        while(!colaAutos.isEmpty()){
            System.out.println(colaAutos.poll());
            // .poll() desencola un elemento
        }
        System.out.println("Longitud de cola: "+colaAutos.size());
        
        //Interface Map
        Map<String,String>mapaSemana;
        
        //Implementación HashMap:   Es la más veloz, pero no garantiza el orden.
        //mapaSemana = new HashMap();
        
        //Implementación Hashtable: Es igual a HashMap, pero es obsoleta
        //mapaSemana = new Hashtable();
        
        //Implementación LinkedHashMap: Almacena elementos en una lista enlazada
        //                                  por orden de ingreso.
        //mapaSemana = new LinkedHashMap();
        
        //Implentación TreeMap: Almacena elementos en un arbol balanceado ordenado
        //                                  por orden natural de llaves
        mapaSemana = new TreeMap();
        
        //app
        mapaSemana.put("lu", "Lunes");
        mapaSemana.put("ma", "Martes");
        mapaSemana.put("mi", "Miércoles");
        mapaSemana.put("ju", "Jueves");
        mapaSemana.put("vi", "Viernes");
        mapaSemana.put("sa", "Sábado");
        mapaSemana.put("do", "Domingo");
        //mapaSemana.put("lu", "xxxxxxx");
        System.out.println(mapaSemana.get("ma"));
        System.out.println("****************************************************");
        mapaSemana.forEach((k,v)->System.out.println(k+" : "+v));
        
    }

}
