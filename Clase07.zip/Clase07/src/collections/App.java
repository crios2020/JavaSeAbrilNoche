package collections;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class App {
    public static void main(String[] args) {
        
        getPersonas().forEach(System.out::println);
        
        System.out.println("****************************************************");
        // Api Stream
        
        //select * from personas;
        getPersonas().stream().forEach(System.out::println);
           
        
        System.out.println("****************************************************");
        //select * from personas where nombre='laura';
        getPersonas()
                .stream()
                .filter(p->p.getNombre().equalsIgnoreCase("laura"))
                .forEach(System.out::println);
        System.out.println("****************************************************");
        for(Persona p:getPersonas()){
            if(p.getNombre().equalsIgnoreCase("laura"))
                System.out.println(p);
        }
        
        System.out.println("****************************************************");
        // select * from personas where nombre like '%a';
        getPersonas()
                .stream()
                .filter(p->p.getNombre().endsWith("a"))
                .forEach(System.out::println);
        
        
        System.out.println("****************************************************");
        // select * from personas where nombre like '%ar%';
        getPersonas()
                .stream()
                .filter(p->p.getNombre().toLowerCase().contains("ar"))
                .forEach(System.out::println);
        
        System.out.println("****************************************************");
        // select * from personas where nombre like '%ar%' and apellido like '%a%';
        getPersonas()
                .stream()
                .filter(p->p.getNombre().toLowerCase().contains("ar") 
                        && p.getApellido().toLowerCase().contains("a"))
                .forEach(System.out::println);
        
        System.out.println("****************************************************");
        // select * from personas where edad <= 30;
        getPersonas()
                .stream()
                .filter(p->p.getEdad()<=30)
                .forEach(System.out::println);
        
        System.out.println("****************************************************");
        // select * from personas where edad between 30 and 40;
        getPersonas()
                .stream()
                .filter(p->p.getEdad()>=30 && p.getEdad()<=40)
                .forEach(System.out::println);
        
        
        //convertir todos los nombres y apellidos a minusculas
        List<Persona> personas=getPersonas();
        personas.forEach(p->{
            p.setNombre(p.getNombre().toLowerCase());
            p.setApellido(p.getApellido().toLowerCase());
        });
        
        
        System.out.println("****************************************************");
        // select * from personas order by apellido;
        personas
                .stream()
                .sorted(Comparator.comparing(Persona::getApellido))
                .forEach(System.out::println);
        
        
        
        System.out.println("****************************************************");
        // orden natural
        personas
                .stream()
                .sorted()
                .forEach(System.out::println);
        
        
        System.out.println("****************************************************");
        // select * from personas order by apellido desc, nombre desc;
        personas
                .stream()
                .sorted(Comparator.comparing(Persona::getApellido).thenComparing(Persona::getNombre).reversed())
                .forEach(System.out::println);
        
        System.out.println("****************************************************");
        // select max(edad) from personas;
        System.out.println(
                personas
                    .stream()
                    .max(Comparator.comparingInt(Persona::getEdad))
                    .get()
                    .getEdad()
        );
        
        
        
    }
    
    public static List<Persona> getPersonas(){
        List<Persona> list=new ArrayList();
        list.add(new Persona("Laura","Perez",26));
        list.add(new Persona("Juan","Perez",20));
        list.add(new Persona("Roxana","Garcia",34));
        list.add(new Persona("Mario","Gomez",43));
        list.add(new Persona("Marina","Lezcano",27));
        list.add(new Persona("Martin","Turi",54));
        list.add(new Persona("Carlos","Ríos",48));
        list.add(new Persona("Miriam","Salinas",47));
        list.add(new Persona("Melina","Miguel",26));
        list.add(new Persona("Andres","Morreti",20));
        list.add(new Persona("Paula","Garcia",20));
        list.add(new Persona("Fernando","Gomez",20));
        list.add(new Persona("Laura","Garrido",46));
        list.add(new Persona("Laura","Gomez",32));
        list.add(new Persona("Marta","Gomez",32));
        list.add(new Persona("Marcela","Gomez",32));
        list.add(new Persona("Mariano","Gomez",32));
        list.add(new Persona("Armando","Gomez",32));
        list.add(new Persona("Ariana","Gomez",32));
        
        return list;
    }
    
}