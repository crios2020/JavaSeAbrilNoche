/*
	Curso:		Java SE Standard Web Programming 11
	Duración:	40 hs.
	Días:		Martes y Jueves
	Horario:	19:00 a 22:00 hs.
	Profe: 		Carlos Ríos			carlos.rios@educacionit.com
 
	Materiales:	alumni.educacionit.com
				user:	email
				pass:	dni
				
				alumnos@educacionit.com
				
	GitHub:		https://github.com/crios2020/JavaSeAbrilNoche
	
	Software:	JDK + IDE
	
	JDK Java Development Kit (Kit de Desarrollo Java)
	
	Versiones LTS 		Long Term Support		8 años.
	
	
	Version				Liberado				Vence
	JDK 8 LTS			Marzo 2014				Marzo 2022
	JDK 9				Octubre 2017			Marzo 2018
	JDK 10				Marzo 2018				Octubre 2018
	JDK 11 LTS			Octubre 2018			Octubre 2026
	JDK 12				Marzo 2019				Octubre 2019
	JDK 13				Octubre 2019			Marzo 2020
	JDK	14				Marzo 2020				Octubre 2020
	JDK 15				Octubre 2020			Marzo 2021
	JDK 16				Marzo 2021				Octubre 2021
	JDK 17 LTS			Octubre 2021			Octubre 2029
	
	
	IDE 	Integrated Development Environment	(Entorno de Desarrollo Integrado)
	
	Eclipse - Netbeans - Spring Tools Suite (STS) - IntelliJ - Theia - JDeveloper
	
	
*/ 

/* Bloque de comentarios */
// Comentario de una sola linea

/**
 *	Comentario Java Doc.
 * 	Debe colocarse delante de una declaración de clase, atributo o método.
 * 	Puede ser leido desde fuera de los archivos binarios.
 */  
public class Clase01{
	public static void main(String[] args){
		System.out.println("Hola Mundo!!");
		
		// Tipo de datos primitivos
		
		// tipo de datos boolean	1 byte
		boolean bo=true;
		bo=false;
		System.out.println(bo);
		
		// tipo de datos byte		1 byte
		byte by=-120;
		by=127;
		System.out.println(by);
		
		// tipo de datos short		2 byte
		short sh=26000;
		System.out.println(sh);
		
		// tipo de datos int		4 byte
		int in=2000000000;
		System.out.println(in);
		
		// tipo de datos long		8 bytes
		long lo=3000000000L;
		System.out.println(lo);
		
		// tipo de datos char(Unicode)		2 bytes
		char ch=65;
		ch+=32;
		ch='f';
		System.out.println(ch);
		
		// tipo de datos float 		32 bits
		float fl=3.45f;
		System.out.println(fl);
		
		// tipo de datos double		64 bits
		double dl=3.45;
		System.out.println(dl);
		
		
		fl=10;
		dl=10;
		
		System.out.println(fl/3);
		System.out.println(dl/3);
		
				
		fl=100;
		dl=100;
		
		System.out.println(fl/3);
		System.out.println(dl/3);
		
		//BigDecimal
		
		// Clase String
		String st="Hola";
		System.out.println(st);
		
		/*
				Clase String JDK 9 o inferior.
				private final char[] value;				
				String st="Hola";					// 8 bytes
				
				Clase String JDK 10 o superior.
				private final byte[] value;
				String st="Hola";					// 4 bytes 
				
		*/ 
		
		
		
		// Vector de un String
		String texto="Esto es una cadena de texto!";
		System.out.println(texto);
		//System.out.println(texto.value[0]);
		System.out.println(texto.length());
		
		//recorrer el vector texto
		for(int a=0; a<texto.length(); a++) System.out.print(texto.charAt(a));
		System.out.println();
		
		//recorrer el vector args
		System.out.println("Longitud vector args: "+args.length);
		for(int a=0; a<args.length; a++) System.out.println(args[a]);
		
		
	}
}
