package clase02;

import javax.swing.JOptionPane;

/**
 * Clase Auto para representa Vehiculos.
 * @author carlos
 */
public class Auto {
    
    //atributos
    String marca;
    String modelo;
    String color;
    int velocidad;
    
    //métodos constructores
    
    /**
     * Este método fue deprecado por Carlos Rios el 22/04/2021
     * por considerarse inseguro. 
     * Usar en su reemplazo public Auto(String marca, String modelo, String color)
     * @deprecated
     */
    @Deprecated
    Auto() {} //constructor vacio
    
    Auto(String marca, String modelo, String color) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
    }
    
    //métodos
    void acelerar(){                                //acelerar
        //velocidad+=10;
        //if(velocidad>100) velocidad=100;
        acelerar(10);
    }
    
    /**
     * Método acelerar personalizado.
     * @param kilometros Cantidad de kilometros a acelerar.
     */
    //método sobrecargado
    void acelerar(int kilometros){                  //acelerarInt
        velocidad+=kilometros;
        if(velocidad>100) velocidad=100;
    }
    
    void acelerar(int j, String x){}                //acelerarIntString
    
    void frenar(){
        velocidad-=10;
    }
    
    void imprimirVelocidad(){
        System.out.println(velocidad);
    }
    
    int getVelocidad(){
        return velocidad;
    }
    
    @Override
    public String toString(){
        return marca+" "+modelo+" "+color+" "+velocidad;
    }
    
    String getEstado(){
        return marca+" "+modelo+" "+color+" "+velocidad;
    }
    
}