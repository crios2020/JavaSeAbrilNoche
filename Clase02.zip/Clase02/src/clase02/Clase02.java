package clase02;

import javax.swing.JOptionPane;



/**
 * Clase principal del proyecto
 * @author carlos
 */
public class Clase02 {

    /**
     * Punto de entrada del proyecto
     * @param args Argumentos que ingresan de consola
     */
    public static void main(String[] args) {
        /*
        Clase 02 Programación Orientada a Objetos
        
        Clases: Es una plantilla para construir objetos. Se encuentra en la vida real
                como un sustantivo.
        
        Clases en Java: son objetos de la clase java.lang.Class 
        
        Objetos: Son instancias de la clases y representan situaciones en especial.
                La clase lang.lang.Object es clase padre de todas la clases.
        
        Atributos:  Los atributos describen a la clase, son variables contenidas dentro 
                    de la clase. Las clases declaran los atriburos y los objetos 
                    completan el estado.
                    Los atributos tienen un proceso de inicialización, las variables NO.
                    Los atributos String se inicializan en null, y los atributos númericos
                    se inicializan en 0.
        
        Atributos en java: son Objetos de la clase java.lang.reflect.Field
        
        Métodos:    Los acciones contenidas dentro de una clase, se detectan como verbos
        
        Métodos en java:    Los métodos son objetos de la clase java.lang.reflect.Method
        
        Sobrecargas de métodos: Ocurre cuando una clases tiene métodos con el mismo nombre, 
                pero con distinta firma de parametros de entrada.
        
        Constructores:  Son métodos que inicializan un objetos, Tienen el mismo nombre que la
                clase y no devuelven parametros de salida. Los constructores pueden sobrecargarse.
                Si una clase no tiene constructores java agrega un constructor vacio al compilar.
        
        Constructores en java: Son objetos de la clase java.lang.reflect.Constructor
        
        */
       
        System.out.println("-- auto1 --");
        Auto auto1=new Auto();  // new Auto() constructor de la clase.
        auto1.marca="Ford";
        auto1.modelo="Fiesta";
        auto1.color="Rojo";
        auto1.acelerar();           //10
        auto1.acelerar();           //20
        auto1.acelerar();           //30
        auto1.frenar();             //20
        auto1.acelerar(13);         //33
        System.out.println(auto1.marca+" "+auto1.modelo+" "+auto1.color+" "+auto1.velocidad);
        
        System.out.println("-- auto2 --");
        Auto auto2=new Auto();
        auto2.marca="Citroen";
        auto2.modelo="C4";
        auto2.color="Bordo";
        for(int a=0;a<=30;a++) auto2.acelerar();
        
        System.out.println(auto2.marca+" "+auto2.modelo+" "+auto2.color+" "+auto2.velocidad);
        
        System.out.println("-- auto3 --");
        Auto auto3=new Auto("Renault", "Clio", "Azul");
        
        //Valor de retorno
        auto3.imprimirVelocidad();
        System.out.println(auto3.getVelocidad());
        //JOptionPane.showMessageDialog(null, "Velocidad: "+auto3.getVelocidad());
        
        
        // método toString()
        System.out.println(auto3.toString());
        System.out.println(auto3);
        System.out.println(auto3.getEstado());
        
        // arquitectura de proyecto
        //JOptionPane.showMessageDialog(null, "Hola a todos!");

        int x;
        //System.out.println(x);
        //error las variables deben ser inicializadas.
        
        Empleado empleado1=new Empleado(1, "Ana", "Perez", 25, 80000);
        //empleado1.sueldoBasico=8000000;
        empleado1.setSueldoBasico(8000000);
        System.out.println(empleado1);
        
        
        /*
            Modificadores de visibilidad de miembros de clases (Atributo o Métodos)
        
        Modificador                 Alcance
        default(Omitido)            El miembro solo es accesible desde la misma clase o
                                    clases del mismo paquete.
        
        public                      El miembro es accesible desde la misma clases
                                    y desde clases de cualquier paquete.
        
        private                     Solo se puede acceder desde la misma clase.
        
        protected                   Se puede accerder desde la misma clase, se puede
                                    acceder desde clases Hijas de cualquier paquete
                                    y desde cualquier clase del mismo paquete
        
        */
    
    }
}
