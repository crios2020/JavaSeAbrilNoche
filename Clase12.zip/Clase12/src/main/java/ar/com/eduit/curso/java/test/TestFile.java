package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.utils.files.FileText;
import ar.com.eduit.curso.java.utils.files.I_File;

public class TestFile {
    public static void main(String[] args) {
        String file="texto.txt";
        I_File fText=new FileText(file);
        fText.setText("Curso de Java!\n");
        fText.appendText("Hoy es Jueves!\n");
        fText.addLine("Lunes.");
        fText.addLine("Martes.");
        fText.addLine("Miércoles.");
        fText.addLine("Jueves.");
        fText.addLine("Viernes.");
        fText.addLine("Sábado.");
        fText.addLine("Domingo.");
        fText.addLine("Lunes.");
        fText.addLine("Martes.");
        fText.addLine("Lunes.");
        
        //System.out.println(fText.getText());
        fText.print();
        
        
        String texto="";
        
        /*
        System.out.println(texto+"\t"+texto.hashCode());
        texto+="h";
        System.out.println(texto+"\t"+texto.hashCode());
        texto+="o";
        System.out.println(texto+"\t"+texto.hashCode());
        texto+="l";
        System.out.println(texto+"\t"+texto.hashCode());
        texto+="a";
        System.out.println(texto+"\t"+texto.hashCode());
        */
        
        // Clase StringBuffer - StringBuilder
        StringBuilder sb=new StringBuilder();
        //StringBuffer sf;
        /*
        System.out.println(sb.toString()+"\t"+sb.hashCode());
        sb.append("h");
        System.out.println(sb.toString()+"\t"+sb.hashCode());
        sb.append("o");
        System.out.println(sb.toString()+"\t"+sb.hashCode());
        sb.append("l");
        System.out.println(sb.toString()+"\t"+sb.hashCode());
        sb.append("a");
        System.out.println(sb.toString()+"\t"+sb.hashCode());
        */
        
//        for(int a=0;a<=6400000;a++){
//            //texto+="x";
//            sb.append("x");
//        }
        
    }
}
