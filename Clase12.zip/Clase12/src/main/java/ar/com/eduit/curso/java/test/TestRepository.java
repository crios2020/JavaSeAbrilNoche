package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.connector.Connector;
import ar.com.eduit.curso.java.entities.Alumno;
import ar.com.eduit.curso.java.entities.Curso;
import ar.com.eduit.curso.java.enums.Dia;
import ar.com.eduit.curso.java.enums.Turno;
import ar.com.eduit.curso.java.repositories.interfaces.I_AlumnoRepository;
import ar.com.eduit.curso.java.repositories.interfaces.I_CursoRepository;
import ar.com.eduit.curso.java.repositories.jdbc.AlumnoRepository;
import ar.com.eduit.curso.java.repositories.jdbc.CursoRepository;

public class TestRepository {
    public static void main(String[] args) {
        I_CursoRepository cr=new CursoRepository(Connector.getConnection());
        Curso curso=new Curso("Cockteleria", "Rios", Dia.LUNES, Turno.NOCHE);
        cr.save(curso);
        System.out.println(curso);
        
        System.out.println("----------------------------------------------------");
        System.out.println(cr.getById(20));
        System.out.println("----------------------------------------------------");
        
        cr.remove(cr.getById(40));
        
        curso=cr.getById(37);
        curso.setDia(Dia.VIERNES);
        cr.update(curso);
        
        System.out.println("****************************************************");
        cr.getAll().forEach(System.out::println);
        
        System.out.println("****************************************************");
        cr.getLikeTitulo("mi").forEach(System.out::println);
        
        System.out.println("****************************************************");
        I_AlumnoRepository ar=new AlumnoRepository(Connector.getConnection());
        Alumno alumno=new Alumno("Josefina", "Riera", 38, 5);
        ar.save(alumno);
        System.out.println(alumno);
        System.out.println("****************************************************");
        ar.getAll().forEach(System.out::println);
        
    }
}