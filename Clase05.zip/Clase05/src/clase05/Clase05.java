package clase05;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Clase05 {

    public static void main(String[] args) {
        //System.out.println(10/0);
        //System.out.println("Esta linea no se ejecuta!");
        
        /*
            Estructura try - catch - finally
        
            try{                                    // bloque obligatorio
                - Colocar las sentencias que pueden lanzar Exception.
                - Estas sentencias tienen más costo de hardware.
                - Si se puede se ejecuta con normalidad.
                - Si ocurre una Exception se cambia el control de ejecución 
                    al bloque catch.
            }catch(Exception e){                    // bloque obligatorio
                - Este bloque se ejecuta en caso de exception en bloque try.
                - Se recibe como parametro un objeto de la clase Exception, 
                    que contiene la descripcion del error.
            }finally{                               // bloque opcional
                - Este bloque se ejecuta siempre.
                - Las variables declaradas en try o catch esta fuera de Scope
            }
            - El programa termina normalmente.
        
        */
        
        /*
        try{
            System.out.println(10/0);
            System.out.println("Esta linea no se ejecuta!");
            
        }catch(Exception e){
            System.out.println("Ocurrio un error!");
            System.out.println(e);
        }finally{
            System.out.println("Este bloque se ejecuta siempre");
        }
        System.out.println("El programa termina normalmente!");
        */
        
        try {
            //GeneradorException.generar();
            //GeneradorException.generar(true);
            //GeneradorException.generar("26x");
            //GeneradorException.generar("hola",20);
            //FileReader in=new FileReader("texto.txt");
        } catch (Exception e) {
            System.out.println(e);
        }
        
        //GeneradorException.generar();
        //FileReader in=new FileReader("texto.txt");
        
        //Captura personalizada de Exceptions
        try {
            //GeneradorException.generar();
            //GeneradorException.generar(true);
            //GeneradorException.generar("26x");
            //GeneradorException.generar("Hola",20);
            FileReader in=new FileReader("texto.txt");
            in.read();
        } catch (ArithmeticException e)                 { System.out.println("División / 0");
        //} catch (ArrayIndexOutOfBoundsException e)      { System.out.println("Indice Fuera de Rango!");
        } catch (NumberFormatException e)               { System.out.println("Formato de número incorrecto!");
        } catch (NullPointerException e)                { System.out.println("Puntero Nulo!");
        //} catch (StringIndexOutOfBoundsException e)     { System.out.println("Indice Fuera de Rango!");
        //} catch (ArrayIndexOutOfBoundsException | StringIndexOutOfBoundsException e) { 
        //    System.out.println("Indice Fuera de Rango!");
        } catch (IndexOutOfBoundsException e)           { System.out.println("Indice Fuera de Rango!");
        } catch (FileNotFoundException e)               { System.out.println("Archivo no encontrado!");
        } catch (IOException e)                         { System.out.println("Error I/O!");   
        } catch (Exception e)                           { System.out.println("Ocurrio un error no esperado!"); }
        
        System.out.println(true || (10+10==22));
        System.out.println(true |  (10+10==22));
        
        System.out.println(false && (10+10==22));
        System.out.println(false &  (10+10==22));
       
        
        // Uso de Exceptions para validar reglas de negocio
        Vuelo v1=new Vuelo("aer1234",100);
        Vuelo v2=new Vuelo("lat1111",100);
        
        try {
            v1.venderPasajes(40);
            v2.venderPasajes(20);
            v1.venderPasajes(50);
            v2.venderPasajes(30);
            v1.venderPasajes(30);               //Esta venta lanza Exception.
            v2.venderPasajes(10);               //Esta venta no se concreta.
        } catch (NoHayMasPasajesException ex) {
            System.out.println(ex);
        }
        
        
        // Try with resources JDK 7
        try (Lector lector=new Lector("texto.txt")){
            lector.leer();
            //throw new IOException();
        } catch (Exception e) {
            System.out.println(e);
        }
        
        
        
        
        
        
        
        /*
        try{
        Lector lector=new Lector("texto.txt");
            try {
                lector.leer();
                lector.close();
            } catch (Exception e) {
                System.out.println(e);
            } finally {
                try{
                    lector.close();
                }catch(Exception e){
                    System.out.println(e);
                }
            }
        }catch(Exception e){
            System.out.println(e);
        }
        */
        
        
        
    }

}
