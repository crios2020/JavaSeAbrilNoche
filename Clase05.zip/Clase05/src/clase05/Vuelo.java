package clase05;

public class Vuelo {
    private String nombre;
    private int pasajesDisponibles;

    public Vuelo(String nombre, int pasajesDisponibles) {
        this.nombre = nombre;
        this.pasajesDisponibles = pasajesDisponibles;
    }

    public synchronized void venderPasajes(int pasajesPedidos) throws NoHayMasPasajesException{
        if(pasajesPedidos>pasajesDisponibles) 
            throw new NoHayMasPasajesException(nombre, pasajesDisponibles, pasajesPedidos);
        pasajesDisponibles-=pasajesPedidos;
    }
    
    @Override
    public String toString() {
        return "Vuelo{" + "nombre=" + nombre + ", pasajesDisponibles=" + pasajesDisponibles + '}';
    }

    public String getNombre() {
        return nombre;
    }

    public int getPasajesDisponibles() {
        return pasajesDisponibles;
    }
    
}